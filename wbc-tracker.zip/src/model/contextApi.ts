export interface MyContextType {
    theme: string;
    user: string;
    toggleTheme: () => void;
  }

  